/**
 * 
 */
package common.data;

/**
 * @author secil.karagulle
 * @author ovunc.bozcan
 */
public class UnsupportedDataContextException extends Exception {

	/**
	 * default constructor
	 */
	public UnsupportedDataContextException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public UnsupportedDataContextException(String message) {
		;
		
	}

}
