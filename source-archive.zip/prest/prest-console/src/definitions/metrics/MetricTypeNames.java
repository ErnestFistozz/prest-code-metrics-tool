/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package definitions.metrics;

/**
 *
 * @author Gürhan
 */
public class MetricTypeNames {
    
    public static final int PACKAGE_METRICS = 0;
    public static final int FILE_METRICS = 1;
    public static final int CLASS_METRICS = 2;
    public static final int METHOD_METRICS = 3;

}
