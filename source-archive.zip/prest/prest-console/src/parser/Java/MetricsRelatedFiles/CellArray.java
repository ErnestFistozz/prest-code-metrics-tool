package parser.Java.MetricsRelatedFiles;

public class CellArray {
	public String name;
	public Cell head = null;
	public CellArray next = null;

	public CellArray(String name) {
		this.name = name;
	}
}
