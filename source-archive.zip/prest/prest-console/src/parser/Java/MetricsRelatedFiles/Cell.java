package parser.Java.MetricsRelatedFiles;

public class Cell {
	public boolean isConnected = false;
	public Cell right = null;
	public Cell below = null;
	public CellArray row = null;
	public CellArray col = null;
}
