package categorizer.core;

/**
 * @author secil.karagulle
 * @author ovunc.bozcan
 */
public class DataHeadersNotMatchingException extends Exception {

	public DataHeadersNotMatchingException(){
		
	}
	
	/**
	 * @param message
	 */
	public DataHeadersNotMatchingException(String message){
		super(message);
	}
	
	/**
	 * @param cause
	 */
	public DataHeadersNotMatchingException(Throwable cause){
		super(cause);
	}
	
	/**
	 * @param message
	 * @param cause
	 */
	public DataHeadersNotMatchingException(String message, Throwable cause){
		super(message, cause);
	}
}
