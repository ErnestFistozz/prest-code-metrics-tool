package categorizer.core;

/**
 * @author secil.karagulle
 * @author ovunc.bozcan
 */
public class InvalidDataItemException extends Exception {

	/**
	 * default constructor
	 */
	public InvalidDataItemException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public InvalidDataItemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
