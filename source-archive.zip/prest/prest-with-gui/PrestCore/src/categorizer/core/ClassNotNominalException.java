/**
 * 
 */
package categorizer.core;

/**
 * @author secil.karagulle
 * @author ovunc.bozcan
 */
public class ClassNotNominalException extends Exception {

	/**
	 * default constructor
	 */
	public ClassNotNominalException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public ClassNotNominalException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
