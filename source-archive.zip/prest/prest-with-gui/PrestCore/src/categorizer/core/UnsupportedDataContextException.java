/**
 * 
 */
package categorizer.core;

/**
 * @author secil.karagulle
 * @author ovunc.bozcan
 */
public class UnsupportedDataContextException extends CategorizerException {

	/**
	 * default constructor
	 */
	public UnsupportedDataContextException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public UnsupportedDataContextException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
