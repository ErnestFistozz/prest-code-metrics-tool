package categorizer.core;

import common.DataContext;

/**
 * @author secil.karagulle
 * @author ovunc.bozcan
 */
public class ThresholdDefinition implements ContextBuilder {

	public void load(DataContext dataContext) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public DataContext store() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
