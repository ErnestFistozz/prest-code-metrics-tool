/**
 * 
 */
package categorizer.core;

/**
 * @author secil.karagulle
 * @author ovunc.bozcan
 */
public class CategorizerNotValidException extends Exception {

	/**
	 * 
	 */
	public CategorizerNotValidException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public CategorizerNotValidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public CategorizerNotValidException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CategorizerNotValidException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
