package categorizer.aiCategorizer.core;

import categorizer.core.Categorizer;
import categorizer.core.DataHeader;
import categorizer.core.DataItem;
import categorizer.core.DataSet;
import categorizer.core.Validator;

import common.DataContext;

/**
 * @author secil.karagulle
 * @author ovunc.bozcan
 */
public abstract class AICategorizer extends Categorizer {

	
	
	/**
	 * default constructor
	 */
	public AICategorizer() {
		super();
		className = "categorizer.aiCategorizer.core.AICategorizer";
		// TODO Auto-generated constructor stub
	}


	/* (non-Javadoc)
	 * @see categorizer.core.Categorizer#buildCategorizer()
	 */
	@Override
	public ConfusionMatrix buildCategorizer() throws Exception {
		// TODO Auto-generated method stub
		return super.buildCategorizer();
	}



	

	/* (non-Javadoc)
	 * @see categorizer.core.Categorizer#categorize(categorizer.core.DataItem)
	 */
	@Override
	public DataItem categorize(DataItem dataItem) throws Exception{
		// TODO Auto-generated method stub
		return super.categorize(dataItem);
	}
	
	

}
