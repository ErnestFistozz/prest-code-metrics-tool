package prestgui;

/**
 * Softlab 2009  
 * @author TurgayA   
 */

public interface IPrestViewListener
{
	public void viewDisposed();
	
}
