package common.gui.controls;

/**
 * Softlab 2009  
 * @author TurgayA   
 */

public interface IComboFilterListener
{
	boolean getFilterMask(TaggedComboBox combo, int index, int iTag);
}
