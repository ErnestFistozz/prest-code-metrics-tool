/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package common.gui.actions;

import categorizer.core.Categorizer;
import common.DataContext;
import definitions.application.ApplicationProperties;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Gürhan
 */
public class StoreCategorizerAdapter implements ActionListener{
    
    private Categorizer categorizer;

    public StoreCategorizerAdapter(Categorizer categorizer) {
        this.categorizer = categorizer;
    }

    public void actionPerformed(ActionEvent e) {
   
    }
    
    public Categorizer getCategorizer() {
        return categorizer;
    }

    public void setCategorizer(Categorizer categorizer) {
        this.categorizer = categorizer;
    }

}