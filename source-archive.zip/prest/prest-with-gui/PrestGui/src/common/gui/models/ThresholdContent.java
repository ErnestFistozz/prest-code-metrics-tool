/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package common.gui.models;

/**
 *
 * @author handee
 */
public class ThresholdContent {
    private String thresholdDataHeader;
    private String thresholdOperator;
    private String thresholdFirstOperand;
    private String thresholdSecondOperand;
    private String thresholdExpression;
    private String thresholdRiskLevel;
    
    public ThresholdContent() {
    }

    public String getThresholdDataHeader() {
        return thresholdDataHeader;
    }

    public void setThresholdDataHeader(String thresholdDataHeader) {
        this.thresholdDataHeader = thresholdDataHeader;
    }

    public String getThresholdExpression() {
        return thresholdExpression;
    }

    public void setThresholdExpression(String thresholdExpression) {
        this.thresholdExpression = thresholdExpression;
    }

    public String getThresholdFirstOperand() {
        return thresholdFirstOperand;
    }

    public void setThresholdFirstOperand(String thresholdFirstOperand) {
        this.thresholdFirstOperand = thresholdFirstOperand;
    }

    public String getThresholdOperator() {
        return thresholdOperator;
    }

    public void setThresholdOperator(String thresholdOperator) {
        this.thresholdOperator = thresholdOperator;
    }

    public String getThresholdSecondOperand() {
        return thresholdSecondOperand;
    }

    public void setThresholdSecondOperand(String thresholdSecondOperand) {
        this.thresholdSecondOperand = thresholdSecondOperand;
    }

    public String getThresholdRiskLevel() {
        return thresholdRiskLevel;
    }

    public void setThresholdRiskLevel(String thresholdRiskLevel) {
        this.thresholdRiskLevel = thresholdRiskLevel;
    }
}
