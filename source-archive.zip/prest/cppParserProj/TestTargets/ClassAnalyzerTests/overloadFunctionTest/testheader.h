
class Foo
{
public:
	Foo();
	Foo(int a, int b);
	~Foo();
	int bar(int a, int b);
	int bar(int a);
}