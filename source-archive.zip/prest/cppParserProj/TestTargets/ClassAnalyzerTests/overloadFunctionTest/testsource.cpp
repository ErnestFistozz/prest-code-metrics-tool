// Default constructor
Foo::Foo()
{

}

// Constructor with two int parameters
Foo(int a, int b)
{

}

// Destructor
~Foo() {}

// Function 'bar' with two parameters
int bar(int a, int b)
{

}

// Funcion 'bar' with one parameter
int bar(int a)
{

}