

class testClass
{
	private:
		int a1;
		int a2;
		char a3;
		Foo* a4;
		void doSomething();
	public:
		testClass();
		~testClass();
}