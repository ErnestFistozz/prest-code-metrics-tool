
Test::doSomething1()
{
	// Basic variable declarations
	int a;
	int b, c;
	int d = 1;
	int e = 2, f = 3;
	
	// Value  / aggregate inits
	int g(3);
	int h{};
	int i = i();
	
	// Pointers
	int* j = new int[10]();
	int* k;
	
	// Inside for-statement
	for(int l = 0; l < 10; ++l)
	{
		// Nothing to do here
	}
	
	while(int l2 = 2 < 10)
	{
		// Loops forever
	}
	
	// Type from other namespace
	Foo::bar m;
	Foo::bar m2 = new bar();
	
	// Pointer type from other namespace
	foo::bar* n;
	
	// Stupid multiplication line that could be handled as a pointer type
	a * b;
	
	// Other non-assigning arithmetic operators
	a + b;
	a - b;
	a / b;
	//a % b;
	
	// Assignment and multiplication
	c = a * b;
	
	// Template
	Foo::Baz<int, double> templateTest;
	
	// Triple scope variable
	Foo::Bar::Baz tripleScopeTest;
	
	double doubleArrayZeroInit[3];
	SomeOtherType otherTypeArray[7];
}