/*
 This test should be used to test if logical lines of code are counted correctly
 Comment after each line tells how  many LLOCS the line should contain
*/
#include <iostream> //1

void Test::TestLLOC()//1
{//0
	; //0
	;
	
	int vInt; //1
	string vStr; //1
	
	if(true) //1
		hello(); //1
	else if(false) //1
		hello2(); //1
	for(int i=0;i<4;i++) //4
		cout <<hello; //1
	for(std::string s: strings) //2
		
	do{ //0
	}while(true) //1
		
		
	
}//0

void hello(){ //1 

} //0



