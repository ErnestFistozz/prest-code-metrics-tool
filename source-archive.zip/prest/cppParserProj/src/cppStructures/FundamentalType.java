package cppStructures;

public enum FundamentalType
{
	NOT_FTYPE, CHAR, SHORT_INT, INT, LONG_INT, BOOL, FLOAT, DOUBLE, LONG_DOUBLE, WCHAR_T
}
