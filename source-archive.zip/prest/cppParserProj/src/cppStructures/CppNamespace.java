package cppStructures;

/**
 * Represents a namespace
 * 
 * @author Harri Pellikka
 * 
 */
public class CppNamespace extends CppScope
{
	/**
	 * Constructs a new namespace
	 * 
	 * @param name
	 *            Name of the namespace
	 */
	public CppNamespace(String name)
	{
		super(name);
	}

}
