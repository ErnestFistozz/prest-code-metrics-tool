package cppStructures;

public class CppStatement
{

}
