package cppParser.utils;
/**
 * This class is responsible for storing collected LOC metrics.
 * @author Tomi
 */
public class LOCMetrics{
    public String file;
	public int commentLines=0,  commentedCodeLines=0, codeOnlyLines=0, emptyLines=0, logicalLOC=0;


    public LOCMetrics() {
    }

    public LOCMetrics(String file, int commentLines, int commentedCodeLines, int codeOnlyLines, int emptyLines, int logicalLOC) {
        this.file = file;
        this.commentLines = commentLines;
        this.commentedCodeLines = commentedCodeLines;
        this.codeOnlyLines = codeOnlyLines;
        this.emptyLines = emptyLines;
        this.logicalLOC = logicalLOC;
    }
	
		
}
