package cppParser;

/**
 * 
 * @author Tomi
 */
public class InvalidParameterException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	InvalidParameterException(String msg)
	{
		super(msg);
	}

}
