package unused;

import unused.FunctionCall;

/**
 * 
 * @author Tomi
 */
public class FunctionCallToken implements ParameterToken
{
	public FunctionCall functionCall;

	public FunctionCallToken(FunctionCall fc)
	{
		this.functionCall = fc;
	}

	@Override
	public String toString()
	{
		return functionCall.toString();
	}

	@Override
	public boolean isFunctionCall()
	{
		return true;
	}
}
