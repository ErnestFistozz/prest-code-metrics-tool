package unused;

/**
 * 
 * @author Tomi
 */
public class VariableToken implements ParameterToken
{

	public String name;
	public String type;
	public boolean primitive;

	@Override
	public boolean isFunctionCall()
	{
		return false;
	}

}
