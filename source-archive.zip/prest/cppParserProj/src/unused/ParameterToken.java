/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package unused;

/**
 * 
 * @author Tomi
 */
public interface ParameterToken
{
	@Override
	public String toString();

	public boolean isFunctionCall();
}
